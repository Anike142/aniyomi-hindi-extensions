
package en.hindianimezone

import eu.kanade.tachiyomi.animeextension.model.*
import eu.kanade.tachiyomi.animeextension.AnimeSource
import okhttp3.*
import org.jsoup.Jsoup
import java.io.IOException

class HindiAnimeZone : AnimeSource {

    override val name = "Hindianimezone"
    override val lang = "en"
    override val supportsLatest = true

    override fun popularAnimeRequest(page: Int): Request {
        return GET("https://hindianimezone.com/page/$page")
    }

    override fun popularAnimeParse(response: Response): AnimesPage {
        val document = Jsoup.parse(response.body?.string())
        val animeList = document.select("div.result-item").map {
            SAnime.create().apply {
                title = it.select("div.title a").text()
                thumbnail_url = it.select("img").attr("src")
                setUrlWithoutDomain(it.select("div.title a").attr("href"))
            }
        }
        return AnimesPage(animeList, hasNextPage = true)
    }

    override fun latestUpdatesRequest(page: Int) = popularAnimeRequest(page)
    override fun latestUpdatesParse(response: Response) = popularAnimeParse(response)
    override fun searchAnimeRequest(page: Int, query: String) =
        GET("https://hindianimezone.com/?s=$query")

    override fun searchAnimeParse(response: Response) = popularAnimeParse(response)

    override fun episodeListParse(response: Response) = listOf<SEpisode>()
    override fun videoListParse(response: Response) = listOf<Video>()

    override fun episodeListRequest(anime: SAnime): Request {
        return GET(anime.url)
    }

    override fun videoListRequest(episode: SEpisode): Request {
        return GET(episode.url)
    }
}
